﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace MOMO_QR_DANANG
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : System.Windows.Application // SỬA: Chỉ định rõ là Application của WPF
    {
    }
}